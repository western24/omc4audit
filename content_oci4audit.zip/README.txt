Content
Sources: [OCI Audit]
Parsers: [OCI Audit]
Fields: [compartment-id, compartment-name, credential-id, event-id, event-name, event-source, event-type, principal-id, request-action, request-agent, request-id, request-origin, request-parameters-actions, request-parameters-avaliablityDomain, request-parameters-compartmentID, request-parameters-endTime, request-parameters-limit, request-parameters-page, request-parameters-softBy, request-parameters-sortOrder, request-parameters-startTime, request-resource, response-payload-id, response-payload-resourceName, response-status, tenant-id, user-name]

Reference
Fields: [mbody, resptime, time]

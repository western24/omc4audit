Content
Sources: [IDCS Custom Audit Log]
Parsers: [IDCS AUDIT]
Fields: [actorDisplayName, actorId, actorName, actorType, adminResourceId, adminResourceName, adminResourceType, adminValuesAdded, adminValuesRemoved, clientId, eventId, id2, idcsCreatedBy_display, idcsCreatedBy_ref, idcsCreatedBy_type, idcsCreatedBy_value, idcsLastModifiedBy_display, idcsLastModifiedBy_ref, idcsLastModifiedBy_type, idcsLastModifiedBy_value, meta_created, meta_lastModified, meta_location, meta_resourceType, meterAsOPCService, quotaCount, rId, reasonValue, samlDecryptedMessage, samlNameIdFormat, samlNameIdValue, samlPartnerId, samlPartnerName, samlPartnerProviderId, serviceName, ssoApplicationHostId, ssoApplicationId, ssoApplicationName, ssoApplicationType, ssoAuthnLevel, ssoCSR, ssoComments, ssoCompletedFactors, ssoIdentityProvider, ssoIdentityProviderType, ssoLocalIp, ssoMatchedSignOnPolicy, ssoMatchedSignOnRule, ssoPolicyObligations, ssoProtectedResource, ssoRp, ssoSessionCreateTime, ssoSessionExpiryTime, ssoSessionId, ssoUserAgent]

Reference
Functions: [Geolocation]
Fields: [cityclnt, clnthostip, continentclnt, continentcodeclnt, countryclnt, countrycodeclnt, ecidid, geolocclnt, mbody, msg, regionclnt, regioncodeclnt, time, usragclntname]
